#include "mylibrary.h"

int main(){
	
	printf("diagonale: %f",diagonaleQuadrato(3.75));
}
