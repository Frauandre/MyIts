#include <stdio.h>


int main(){
	
	char stringa[5];
	
	printf("Inserisci una frase di 5 caratteri: ");
	scanf("%5s",&stringa);
	
	printf("\n\nFrase inserita: %s",stringa);
}
