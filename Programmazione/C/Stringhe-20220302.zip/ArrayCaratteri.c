#include <stdio.h>


int main(){
	
	char caratteri[5];
	caratteri[0]='C';
	caratteri[1]='i';
	caratteri[2]='a';
	caratteri[3]='o';
	caratteri[4]='!';
	
	int i;
	for(i=0;i<5;i++)
		printf("%c",caratteri[i]);
}
