#include <stdio.h>

int main(){
	
	char nome[30] = {"Piero Calamandrei"};
	
	printf("Stringa: %s",nome);
	
	char *p = "Piero Calamandrei";
	
	printf("\nStringa (*p): %s",p);
	
	
}

