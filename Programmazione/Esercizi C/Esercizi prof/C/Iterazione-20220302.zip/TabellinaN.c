/*
Stampare la tabellina di un certo numero intero dato in input
*/

#include <stdio.h>

int main(){
	int n;
	printf("Inserisci un numero intero positivo: ");
	scanf("%d",&n);
	
	printf("Tabellina del %d\n\n",n);
	int i;
	for(i=1;i<=10;i++)
		printf("\t%d",n*i);
		
}
