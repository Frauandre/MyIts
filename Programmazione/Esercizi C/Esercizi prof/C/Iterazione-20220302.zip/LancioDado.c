#include <stdio.h>
#include <math.h>
#include <time.h>

int main(){
	
	srand(time(NULL)); //mescolamento
	int numeroFacce = 6;
	int casuale = rand();	//genera un numero casuale
	int casuale2 = casuale%numeroFacce; // [0, numeroFacce-1]
	int dado = casuale2+1;//[1, numeroFacce]
	
	printf("lancio del Dado: %d", dado);
}
