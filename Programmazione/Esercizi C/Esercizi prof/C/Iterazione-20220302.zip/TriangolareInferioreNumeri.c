/*

1
12
123
1234
12345
123456
1234567

Dato in input un numero intero positivo, 
stampare la matrice triangolare inferiore di numeri crescenti
*/
#include <stdio.h>

int main(){
	
	int n;
	printf("Inserisci un numero intero positivo: ");
	scanf("%d",&n);
	
	int i,j;
	for(i=1;i<=n;i++){
		for(j=1;j<=i;j++)
			printf("%d",j);
		printf("\n");
	}
	
}


