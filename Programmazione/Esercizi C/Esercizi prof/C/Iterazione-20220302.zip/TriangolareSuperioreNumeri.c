/*
output 1
1234567
123456
12345
1234
123
12
1

output 2
1234567
 123456
  12345
   1234
    123
     12
      1

output 3
      1
     12 
    123
   1234
  12345
 123456
1234567
  
Dato in input un numero intero positivo, 
stampare la matrice triangolare inferiore di numeri crescenti
*/
#include <stdio.h>

int main(){
	
	int n;
	printf("Inserisci un numero intero positivo: ");
	scanf("%d",&n);
		
	int i,j,k;
	
	//output 1
	for(i=0;i<n;i++){
		for(j=1;j<=n-i;j++)
			printf("%d",j);
		printf("\n");
	}
	
	printf("\n\n");
	//output 2
	for(i=0;i<n;i++){ //righe
		for(k=0;k<i;k++)
			printf(" ");
		for(j=1;j<=n-i;j++) //colonne
			printf("%d",j);
		printf("\n");
	}
		
	printf("\n\n");
	//output 3
	for(i=1;i<=n;i++){ //righe
		for(k=0;k<n-i;k++)
			printf(" ");
		for(j=1;j<=i;j++) //colonne
			printf("%d",j);
		printf("\n");
	}
}


