/* 
Dati N numeri interi in input, visualizzare il max
 */
#include <stdio.h>
#include <limits.h>
//https://stackoverflow.com/questions/2053843/min-and-max-value-of-data-type-in-c

int main(){
	
	int n=0; //quanti numeri sono stati inseriti
	int min=INT_MAX; //variabile che contiene il valore min inserito
	int flag; //vuoi continuare?
	
	 //contatore per il ciclo for
	int numero; //variabile per acquisire da input il numero di volta in volta
	do{		
		printf("Inserisci un numero: ");
		scanf("%d",&numero);
		
		if(min>numero)
			min = numero;
		
		n++; //inserito un nuovo numero
		
		printf("Vuoi continuare? (1=Si,0=No)");
		scanf("%d",&flag);
		
	}while(flag==1);
	
	printf("\n\nStampa dei risultati\n\n");
	printf("Sono stati inseriti %d numeri\n",n);
	printf("Min: %d\n",min);				
}
